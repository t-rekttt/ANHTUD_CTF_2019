chmod -R 777 src/.data
chmod -R 777 src/logs
chmod 777 src
docker-compose up -d --build
