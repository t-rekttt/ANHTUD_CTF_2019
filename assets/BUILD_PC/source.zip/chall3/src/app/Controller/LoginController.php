<?php
namespace App\Controller;

use App\Model\User;
use App\Util\Logger;

class LoginController extends Controller
{
    function get()
    {
        return $this->view('login');
    }

    function post()
    {
        $username = isset($_POST['username']) ? $_POST['username'] : '';
        $password = isset($_POST['password']) ? sha1($_POST['password']) : '';
        $user = User::auth($username, $password);
        if(isset($user)) 
        {
            $this->auth($user);
            header('location: index.php');
            return true;
        }
        $this->data['error'] = 'username or password not match';
        return $this->view('login');
    }

    function logout()
    {
        $this->sessionInvalidate();
        header('location: index.php?page=login');
    }

}