<?php
namespace App\Controller;

use App\Model\Comment;

class HomeController extends Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->authentication();
        header('location: index.php?page=shop');
    }
}
?>