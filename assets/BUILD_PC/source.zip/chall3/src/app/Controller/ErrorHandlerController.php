<?php

namespace App\Controller;

class ErrorHandlerController extends Controller
{
    function _404()
    {
        return $this->view('404');
    }

    function _405()
    {
        return $this->view('405');
    }
}