<?php
namespace App\Controller;

use App\Model\Item;
use App\Model\User;
use App\Util\Database\Database;

class ShopController extends Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->authentication();
        $items = Item::findAll();
        $this->data['items'] = $items;
    }
    
    function get()
    {
        return $this->view('shop');
    }

    function post()
    {
        if(isset($_POST['item_id']))
        {
            return $this->buyItem($_POST['item_id']);
        }
        return $this->view('shop');
    }
    
    function buyItem($id)
    {
        $user = User::findById($this->auth()->id);
        $item = Item::findById($id);
        if(!isset($item))
        {
            return $this->view('404');
        }
        if($user->money >= $item->price)
        {
            //add item to cart
            $con = Database::newConnection();
            $con->queryUpdate("insert into user_items(user_id, item_id) values(?, ?)", [$user->id, $item->id]);
            $con->close();
            $user->money -= $item->price;
            $user->update();
            $this->auth()->money -= $item->price;
            $this->data['success'] = 'Buy item success. Check your cart';
        }
        else 
        {
            $this->data['error'] = 'Không tiền mà đòi muốn mua thì có mua **** mua c**';
        }
        return $this->view('shop');
    }
    
}
?>