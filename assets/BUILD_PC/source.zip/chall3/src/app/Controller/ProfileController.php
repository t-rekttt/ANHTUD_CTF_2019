<?php
namespace App\Controller;

use App\Model\User;
use App\Util\Logger;

class ProfileController extends Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->authentication();
        $this->logger = new Logger('logs/'.$this->auth()->username.'.log');
        if(isset($_REQUEST['action']))
        {
            $this->data['action'] = $_REQUEST['action'];
        }
    }
    
    function get()
    {
        if(isset($this->data['action']) && $this->data['action'] === 'log')
        {
            $this->logUpdate();
        }
        return $this->view('profile');
    }

    function post()
    {
        if(isset($this->data['action']) && $this->data['action'] === 'changepasswd')
        {
            $oldPassword = isset($_POST['oldpassword']) ? $_POST['oldpassword'] : '';
            $newPassword = isset($_POST['password']) ? $_POST['password'] : '';
            return $this->updatePassword($oldPassword, $newPassword);
        }
        return $this->updateProfile(isset($_POST['name']) ? $_POST['name'] : '');
    }

    function updateProfile($name)
    {
        if(!empty($name))
        {
            if(strlen($name) <= 10)
            {
                $user = $this->auth();
                $user->name = $name;
                $user->update();
                $this->auth($user);
                $this->data['success'] = 'update success';
                $this->logger->log("change name to $name success");
            }
            else
            {
                $this->data['error'] = "name only < 10 char";
            }
            return $this->view('profile');
        }
        $this->data['error'] = 'name empty';
        return $this->view('profile');
    }

    function updatePassword($oldPassword, $newPassword)
    {
        $oldPassword = sha1($oldPassword);
        $newPassword = sha1($newPassword);
        $user = User::auth($this->auth()->username, $oldPassword);
        if(isset($user)) 
        {
            $user->password = $newPassword;
            $user->update();
            $this->data['success'] = 'update success';
            return $this->view('profile');
        }
        $this->data['error'] = 'old password not correct';
        return $this->view('profile');
    }

    function logUpdate()
    {
        $path = isset($_REQUEST['name']) ? $_REQUEST['name'] : $this->auth()->username.".log";
        if(strpos($path, "..") !== false)
        {
            $this->data['logcontent'] = "hack detected!!!";
        }else{
            $path = "logs/".$path;
            ob_start();
            @include ($path);
            $this->data['logcontent'] = ob_get_clean();
        }
    }
}
?>