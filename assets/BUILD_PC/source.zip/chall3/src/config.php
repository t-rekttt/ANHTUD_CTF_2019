<?php

define('ROOT_PATH', __DIR__);
//database
const DB = [
    // 'mysql' => [
    //     'host' => 'localhost',
    //     'database' => 'chall3',
    //     'user' => 'root',
    //     'password' => ''
    // ],
    'sqlite' => [
        'url_connection' => 'sqlite:.data/data.sqlite'
    ]
];

const flag = "flag{test_flag}";
